import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function Component() {
  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      {/* Cosmic background overlay */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-blue-900/20 via-purple-900/20 to-pink-900/20" />

      <div className="relative z-10">
        {/* ---------- HEADER ---------- */}
        <header className="container mx-auto px-4 py-10">
          <div className="flex flex-col items-center space-y-6 text-center">
            <div className="flex items-center space-x-4">
              <Image
                src="/nebulasites-logo.png"
                alt="NebulaSites logo"
                width={80}
                height={80}
                priority
                className="rounded-lg"
              />
              <h1 className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-4xl font-extrabold text-transparent md:text-6xl">
                NebulaSites
              </h1>
            </div>

            <p className="max-w-3xl text-xl leading-relaxed text-gray-300 md:text-2xl">
              AI-Powered Websites & Logos – Delivered in 48h. Clean. Fast. Affordable.
            </p>
          </div>
        </header>

        {/* ---------- PRICING ---------- */}
        <main className="container mx-auto px-4 pb-16">
          <div className="mx-auto mb-14 grid max-w-6xl gap-8 md:grid-cols-3">
            {/* LOGO ONLY */}
            <Card className="bg-slate-800/50 backdrop-blur-sm hover:scale-105 hover:bg-slate-800/70 transition">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-white">Logo Only</CardTitle>
                <div className="mt-2 flex items-center justify-center gap-3">
                  <span className="text-2xl text-gray-400 line-through">$55</span>
                  <span className="text-4xl font-bold text-blue-400">$25</span>
                </div>
                <div className="text-sm text-green-400 font-semibold">Save $30!</div>
              </CardHeader>
              <CardContent className="space-y-4">
                <CardDescription className="mb-4 text-center text-gray-300">
                  Perfect for new businesses needing professional branding
                </CardDescription>

                {["3 professional logo concepts", "High-resolution files", "Professional mockups", "48h delivery"].map(
                  (item) => (
                    <Feature key={item} label={item} />
                  ),
                )}
              </CardContent>
            </Card>

            {/* LANDING PAGE – MOST POPULAR */}
            <Card className="relative bg-slate-800/50 backdrop-blur-sm hover:scale-105 hover:bg-slate-800/70 transition border-purple-500">
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 px-4 py-1 text-sm font-semibold">
                Most Popular
              </span>
              <CardHeader className="pt-7 text-center">
                <CardTitle className="text-2xl text-white">Landing Page</CardTitle>
                <div className="mt-2 flex items-center justify-center gap-3">
                  <span className="text-2xl text-gray-400 line-through">$69</span>
                  <span className="text-4xl font-bold text-purple-400">$59</span>
                </div>
                <div className="text-sm text-green-400 font-semibold">Save $10!</div>
              </CardHeader>
              <CardContent className="space-y-4">
                <CardDescription className="mb-4 text-center text-gray-300">
                  Complete responsive website ready to convert visitors
                </CardDescription>

                {[
                  "Responsive single-page website",
                  "Modern, clean design",
                  "Mobile-optimised & fast",
                  "48h delivery",
                ].map((item) => (
                  <Feature key={item} label={item} />
                ))}
              </CardContent>
            </Card>

            {/* WEBSITE + LOGO */}
            <Card className="bg-slate-800/50 backdrop-blur-sm hover:scale-105 hover:bg-slate-800/70 transition">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-white">Website + Logo</CardTitle>
                <div className="mt-2 flex items-center justify-center gap-3">
                  <span className="text-2xl text-gray-400 line-through">$120</span>
                  <span className="text-4xl font-bold text-pink-400">$80</span>
                </div>
                <div className="text-sm text-green-400 font-semibold">Save $40!</div>
              </CardHeader>
              <CardContent className="space-y-4">
                <CardDescription className="mb-4 text-center text-gray-300">
                  Complete branding solution for your business
                </CardDescription>

                {[
                  "Everything from Landing Page",
                  "3 professional logo concepts",
                  "Custom branding integration",
                  "Brand colour palette",
                  "48h delivery",
                ].map((item) => (
                  <Feature key={item} label={item} />
                ))}
              </CardContent>
            </Card>
          </div>

          {/* ---------- CTA ---------- */}
          <div className="text-center">
            <Link href="https://wa.me/5511974295008" target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                className="rounded-full bg-gradient-to-r from-green-500 to-green-600 px-8 py-4 text-lg font-semibold text-white shadow-lg transition hover:scale-105 hover:from-green-600 hover:to-green-700"
              >
                Request via WhatsApp
              </Button>
            </Link>
          </div>
        </main>

        {/* ---------- FOOTER ---------- */}
        <footer className="container mx-auto border-t border-slate-700/50 px-4 py-10 text-center">
          <p className="text-gray-400">© 2025 NebulaSites. AI-powered web creation.</p>
        </footer>
      </div>
    </div>
  )
}

/* ---------- Small helper component ---------- */
function Feature({ label }: { label: string }) {
  return (
    <li className="flex items-center space-x-3">
      <Check className="h-5 w-5 flex-shrink-0 text-green-400" />
      <span className="text-gray-300">{label}</span>
    </li>
  )
}
