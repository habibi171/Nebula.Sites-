import Component from "../nebulasites-landing"

export default function Page() {
  return <Component />
}
